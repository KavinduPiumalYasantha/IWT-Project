function myFunction() {
      alert("New Page Loaded");
	 
}