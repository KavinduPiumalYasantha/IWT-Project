function myFunction() { // New page loding alert
    alert("New Page Loaded");
    
}


function my2Function() { // facebook login 
    var fb = confirm("Do you want to log Facebook?"); // ask to confirm log with facebook
    
    if(fb){

        window.open("https://www.facebook.com/"); // open new windows to relevent link
    }
    else{
        alert("Welcome Back to home"); // you not log with facebook display welcome back to home page

    }

    

}

function my3Function() { // Twitter login
    var twit = confirm("Do you want to log Twitter?"); // ask to confirm log with twitter

    if(twit)
    {
        window.open("https://twitter.com/"); // open new windows to relevent link

    }

    else{
        alert("Welcome back to home"); // you not log with twitter display welcome back to home page

    }
    
}

function my4Function() { // Instagram login
    var insta = confirm("Do you want to log Instagram?");  // ask to confirm log with intagram

    if(insta)
    {
        window.open("https://www.instagram.com/"); // open new windows to relevent link

    }
    else{
        alert("Welcome back to home"); // you not log with instagram display welcome back to home page

    }
    
}

function my5Function() {  // Gmail login
    var gamil= confirm("Do you want to log Gmail?"); // ask to confirm log with gmail

    if(gamil)
    {

        window.open("https://mail.google.com"); // open new windows to relevent link
    }

    else{

        alert("Welcome back to home"); // you not log with gmail display welcome back to home page

    }
    
}

