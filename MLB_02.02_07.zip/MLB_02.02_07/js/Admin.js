function my2Function() {
    alert("Do you want to log Facebook?");
    
}

function my3Function() {
    alert("Do you want to log Twitter?");
    
}

function my4Function() {
    alert("Do you want to log Instagram?");
    
}

function my5Function() {
    alert("Do you want to log Gmail?");
    
}

function my6Function() {
    alert("Do you want to go customer page?");
    
}

function my7Function() {
    alert("Do you want to go seller page?");
    
}

function my8Function() {
    alert("Do you want to go book page?");
    
}
function my9Function() {
    alert("Do you want to go chat page?");
    
}

function my10Function() {
    alert("Do you want to go payment page?");
    
}
function my11Function() {
    alert("Do you want to go orders page?");
    
}


