



function mysaveFunction() {   
    document.getElementById('name').disabled = true;
    document.getElementById('email').disabled = true;
    document.getElementById('address').disabled = true;
	document.getElementById('phone').disabled = true;
    }
	
	
	
	
function myFunction() {   
document.getElementById('name').disabled = false;
    document.getElementById('email').disabled = false;
    document.getElementById('address').disabled = false;
	document.getElementById('phone').disabled = true;
}