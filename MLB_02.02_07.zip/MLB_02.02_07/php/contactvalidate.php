<?php
require 'dbconnection.php';

session_start();


if(isset($_POST['contactUs_btn']))
{
    global $conn;
    $name = $_POST ['name'];
    $email = $_POST['email'];
    $msg = $_POST['message'];


    $query = "INSERT INTO contactus(username,email,message)VALUES('$name','$email','$msg')";
    $query_run = mysqli_query($conn,$query);

    if($query_run)
    {
        
        // $_SESSION['ID'] = $row['ID'];
        $_SESSION['name'] = $name;
        $_SESSION['email'] = $email;
        $_SESSION['message'] = $msg;
          

        $_SESSION['status'] = "Data inserted!";
        header("location: update.php"); 
    }else{
        $_SESSION['status'] = "Data inserted failed!!";
        header("location: contactUS.php"); 
    }
}



if(isset($_POST['update_btn'])){
    global $conn;
    $email = $_POST['mail'];
    $msg = $_POST['message'];


    $query = "UPDATE contactus SET message = '$msg' WHERE email='$email'";
    $query_run = mysqli_query($conn,$query);

    if($query_run)
    {
        
        $_SESSION['status'] = "Update Successful";
        header("location: message.php"); 
    }else{
        $_SESSION['status'] = "Update failed!!";
        header("location: message.php"); 
    }
}


if(isset($_POST['delete_btn'])){
    global $conn;
    $email = $_POST['mail'];


    $query = "DELETE FROM contactus WHERE email='$email'";
    $query_run = mysqli_query($conn,$query);

    if($query_run)
    {
        $_SESSION['status'] = "Record Deleted";
        header("location: message.php"); 
    }else{
        $_SESSION['status'] = "Delete failed!!";
        header("location: message.php"); 
    }
}
?>