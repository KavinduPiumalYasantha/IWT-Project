<?php
//Linking the configuration file

//The connection object
$con=new mysqli("localhost","root","","project");
// Check connection
	if($con->connect_error){
		die("Connection failed: " . $con->connect_error);
	}
$S_ID = $_GET['id'];
$query = "delete from seller where S_ID = '$S_ID'";

$data = mysqli_query($con,$query);

if($data){
    echo "<script>alert ('Record deleted successfully!')</script>";
    header ("location:seller.php");
}
else{
    echo"<script>alert ('erre')</script>";
}
mysqli_close($con);

?>    