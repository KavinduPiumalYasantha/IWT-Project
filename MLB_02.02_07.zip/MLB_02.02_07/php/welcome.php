<!--
Into this file, we create a layout for welcome page.
-->

<?php
include_once('link.php');
include_once('header.php');
require_once('connection.php');

?>
<div class="jumbotron">
	<center>
		<h1>Login Successfully</h1>
	</center>
</div>