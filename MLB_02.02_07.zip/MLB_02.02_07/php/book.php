<!DOCTYPE html>
<html>
	<head>
		<style> 
        body
           {
                background-image: url("Pic/main.jpg");

           }
            
			table{
				border-collapse: collapse;
				width:100%;
				color: #004080;
				font-family: monospace;
				font-size: 20px;
				text-align:left;
                background-color:#ffffff;
                
                
			}

			th{
				background-color:#004080;
				color:#e6f2ff;
			}

			tr:nth-child(even){
				background-color:#e6f2ff;
			}
            .div{
                width: 800px;
                height: 420px;
                border: 1px solid darkslategrey;
                background-color:rgba(11, 28, 31, 0.699);
                border-radius: 20px;
                margin-top: 30px;
                margin-left: 350px;
                
    
            }

            .Add{
                text-align: center;
                color: rgb(211, 211, 211);
                font-family: 'Courier New';
                font-size: 40px;
            }
            .Name{
                text-align: center;
                color: rgb(211, 211, 211);
                font-family: 'Courier New';
            }

            .text1{
                width: 500px;
                height: 30px;
                margin-left: 30px;
                opacity: 0.6;
                border-radius: 10px;
            }
            .text2{
                width: 500px;
                height: 30px;
                margin-left: 0px;
                opacity: 0.6;
                border-radius: 10px;
            }
            .text3{
                width: 500px;
                height: 30px;
                margin-left: -10px;
                opacity: 0.6;
                border-radius: 10px;
            }
            .text4{
                width: 500px;
                height: 30px;
                margin-left: 0px;
                opacity: 0.6;
                border-radius: 10px;
            }
            .sbtn
            {
                margin-left: 400px;
                width: 150px;
                height: 50px;
                
                font-size: 20px;
                border-radius: 10px;
                cursor: pointer;
                opacity: 0.9;
                font-weight: bold;
                
            }
            .sbtn:hover
            {
                font-size: 22px;
            }
    		</style>	
	</head>
<body>
<table>
	<tr>
		<th>Book ID</th>
		<th>Name</th>
		<th>Price</th>
		<th>Seller ID</th>
		<th>Action</th>
    </tr>			
		
<?php
//Linking the configuration file

//The connection object
$con=new mysqli("localhost","root","","project");
// Check connection
	if($con->connect_error){
		die("Connection failed: " . $con->connect_error);
	}

$sql = "select B_ID,B_Name,B_Price,S_ID from book";
$result = $con->query($sql);



	if($result->num_rows > 0){
		//read data
		while($row = $result->fetch_assoc()){
		echo"
		<tr>
		    <td>".$row['B_ID']."</td>
			<td>".$row['B_Name']."</td>
			<td>".$row['B_Price']."</td>
			<td>".$row['S_ID']."</td>
			<td><a href = 'bookdelete.php?id=$row[B_ID]'>
			<input type='submit' value = 'Delete'></a></td>
		</tr>";	
		
		}
	}
	else
	{
		echo "no results";
	}
$con->close();
?>
</table>
<div class="div">
<form action = "addbook.php" method = "post">
<h1 class="Add">Add New Book </h1>
<h2 class="Name">1) Book ID :  <input type="text" class="text1" name = "B_ID" id = 'B_ID' ></h2>
<h2 class="Name">2) Book Name :  <input type="text" class="text2" name = "B_Name" id = 'B_Name' ></h2>
<h2 class="Name">3) Book Price :  <input type="text" class="text3" name = "B_Price" id = 'B_Price' ></h2>
<h2 class="Name">4) Seller ID :  <input type="text" class="text4" name = "S_ID" id = 'S_ID' ></h2>
<input type="submit" class="sbtn" value="Add Book" name = "stmt">
</form>
</div>
</body>
</html>