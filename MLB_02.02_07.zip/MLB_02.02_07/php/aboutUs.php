<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/test.css" type="text/css"> 
    <link rel="stylesheet" href="css/contact_us.css"> 
</head>
<body>
    <body  style="background-image: url(pic/1.jpg);">
        <body style="background-color:white;">
    
            <table  class="headtable">
                <td><a href="IWT Project 2.HTML"><img src="pic/logo.jpg" class="logo"></a></td>
                <td><form>
                <input type="sreach" name="Book" placeholder="Search Book" class="sreach" >
                </form></td>
                <td><button class="signin">Sign in</button></td>
                <td><button class="register">Register</button></td>
                <td><img src="pic/profile.jpg" class="profile">  </td>
             </table>
        
                  <div class="nav1">
                      <a href="IWT Project 2.HTML"class = "home">Home</a>
                      <a href="category.html "class = "category">Category</a>
                      <a href="contact.html"class = "contact">Contact Us</a>
                      <a href="about.html"class = "about">About Us</a> 
                  </div> 
                  <div>

                    <div class="p1">
                        <div style="padding-top :30px  ; text-align: center; color: lightcoral;">
                            <h2>About Us</h2>
                        </div>
                        <div class="paragrap" style="background-image: url(pic/wp2036902.jpg) ;" >
                        <p>Manthoughtbooks.com is the e-learning  library portal of manthought books the leading books onlie seller in Sri Lanka. <br>
                            Customer satisfaction and online security is our priority. <br><br><br> Manthoughtbooks.com is the top online book buying destination for thousands of customers  as a pioneer of book online sales in Sri Lanka.The main reason for this is that our vision is to provide  quality , quantitative and efficient service to our customers. <br><br><br> Manthoughtbooks.com has invented in modern technology and made the online book buying experience to our many thousands of satisfied customers simple , convenient and secure.It has a huge collection of over thousand titles and is a one stop destination on the web to find popular best sellers as well as rare books. <br><br><br> Having a strong relationship with publishers around the world has helped us provide a more effective service to our readers.So manthoughtbooks.com has the largest selection of books than any other online bookstore in Sri Lanaka.Manthought books endeavours to be the best option for buying books online.
                        </div>
                        <br><br><br>
                           <p style="text-align: center; color: deeppink; font-size: x-large;"> We welcome you to experience our service...</p> 
                    
                </div>
                   
                    </div>
                  </div>

                  <footer>
  
                    <table  class="footertable">
                      <td><img src="pic/Payment.jpg" class="paymentpic"></td>
                      <td><h4 class="copytex"><b>Copyright @ 2021 by </b> ManThoughtsBookStore.com</h4></td>
                      <td><a href="https://www.facebook.com/"><img src="pic/fb.jpg" class="fbpic"></a></td>
                      <td><a href="https://twitter.com/"><img src="pic/twitter.jpg" class="fbpic"></a></td>
                      <td><a href="https://www.instagram.com/"><img src="pic/instagram.jpg" class="fbpic"></a></td>
                      <td><a href="https://mail.google.com"><img src="pic/gmail.jpg" class="fbpic"></a></td>
                      <td><img src="pic/app.jpg" class="apppic"></td>
                    </table>
                </footer>
                 
</body>
</html>