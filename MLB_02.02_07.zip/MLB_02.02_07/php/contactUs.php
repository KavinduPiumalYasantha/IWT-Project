<?php session_start()
  
?>
<!DOCTYPE html> 
<html>
    <title> Contact Us </title>
<head>
<link rel="stylesheet" href="css/test.css" type="text/css"> 
<link rel="stylesheet" href="css/contact_us.css">
<!-- js -->
<script>
    alert("Welcoe to My Page");
</script>
</head>
<body>
    <table  class="headtable">
        <td><a href="IWT Project 2.HTML"><img src="pic/logo.jpg" class="logo"></a></td>
        <td><form>
        <input type="sreach" name="Book" placeholder="Search Book" class="sreach" >
        </form></td>
        <td><button class="signin">Sign in</button></td>
        <td><button class="register">Register</button></td>
        <td><img src="pic/profile.jpg" class="profile">  </td>
     </table>
     
     
          <div class="nav1">
          <!-- this pages would be connect -->
              <a href="IWT Project 2.HTML"class = "home">Home</a>
              <a href="category.html "class = "category">Category</a>
              <a href="contactUs.php"class = "contact">Contact Us</a>
              <a href="aboutUs.php"class = "about">About Us</a>
          </div>

          <div style="background-image: url(pic/bg8.jpg)">
            <section class="cntact">
               
                <div class="cntainer">
                    <div class="contactInfo">
                        <div class="box">
                            <div class="icon"><img src="pic/address.png" width="50" height="50"></div>
                            <div class="text">
                                <h3>Address</h3>
                                <p>47,<br> Hyde Park Corner,<br>Colombo 02</p>
                            </div>
                        </div>
                        <div class="box">
                            <div class="icon"><img src="pic/call.png" width="50" height="50"></div>
                            <div class="text">
                                <h3>Phone</h3>
                                <p>Marketing&nbsp;&nbsp;&nbsp;&nbsp;: (011) 2335704<br>Admin&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: (011) 4xxxxxx<br></p>
                            </div>
                        </div>
                        <div class="box">
                            <div class="icon"><img src="pic/email.png" width="50" height="50"></div>
                            <div class="text">
                                <h3>Email</h3>
                                <p> Marketing&nbsp;&nbsp;&nbsp;&nbsp;: info@manthoughtbookstore.lk<br>Admin&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: admin@manthoughtbookstore.lk<br></p>
                            </div>
                        </div>
                    </div>
                    <div class="contactForm">
                      
                            
                            <?php
                            if(isset($_SESSION['status'])) : ?>
                              <?php echo "<h4>".$_SESSION['status']."</h4>";
                              unset($_SESSION['status']); ?>

                              <form action="contactvalidate.php" method="POST">
                                  <h2>Update</h2>
                                  <div class="inputBox">
                                  <input type="text" name="name" value="<?php $_SESSION['name'] ?>" readonly>
                                  <span>Full Name</span>
                                  </div>
                                  <div class="inputBox">
                                      <input type="email" name="email" value="<?php $_SESSION['email'] ?>"  readonly>
                                      <span>E-mail</span>
                                  </div>
                                  <div class="inputBox">
                                      <textarea name="message" value="<?php $_SESSION['message'] ?>"></textarea>
                                      <span>Add Your Message Here</span>
                                  </div>
                                  <input type ="hidden" name ="id" value="<?php $_SESSION['ID'] ?>" >
                                  <div class="inputBox">
                                      <input type="submit" name="update_btn" value="Update">
                                  </div>
                              </form>
                            <?php else: ?>
                              <form action="contactvalidate.php" method="POST">
                                  <h2>Contact Us</h2>
                                  <div class="inputBox">
                                  <input type="text" name="name">
                                  <span>Full Name</span>
                                  </div>
                                  <div class="inputBox">
                                      <input type="email" name="email">
                                      <span>E-mail</span>
                                  </div>
                                  <div class="inputBox">
                                      <textarea name="message"></textarea>
                                      <span>Add Your Message Here</span>
                                  </div>
                                  <div class="inputBox">
                                      <input type="submit" name="contactUs_btn" value="Send">
                                  </div>
                              </form>
                            <?php endif; ?>
                          
                    </div>
                  </div>
                </section>
             </div>   
             </div>
         </section>
     </div>
         
    <footer>
  
        <table  class="footertable">
          <td><img src="pic/Payment.jpg" class="paymentpic"></td>
          <td><h4 class="copytex"><b>Copyright @ 2021 by </b> ManThoughtsBookStore.com</h4></td>
          <td><a href="https://www.facebook.com/"><img src="pic/fb.jpg" class="fbpic"></a></td>
          <td><a href="https://twitter.com/"><img src="pic/twitter.jpg" class="fbpic"></a></td>
          <td><a href="https://www.instagram.com/"><img src="pic/instagram.jpg" class="fbpic"></a></td>
          <td><a href="https://mail.google.com"><img src="pic/gmail.jpg" class="fbpic"></a></td>
          <td><img src="pic/app.jpg" class="apppic"></td>
        </table>
    </footer>


</body>
</html>