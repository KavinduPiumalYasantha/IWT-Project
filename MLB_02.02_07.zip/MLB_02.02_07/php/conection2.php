<?php

    $servername = "localhost";
	$username = "root"
	$passworde = "";
	$db = "mtbstore";
	
    //Creat conection
	$conn = new mysqli($servername, $username, $password);
	
    //Check connection
	if ($conn->connect error) {
		die("Connection failed: " . $conn->connect error);
		
	}
	
	echo "Connected successfully";

?>-
