<?php
//Linking the configuration file

//The connection object
$con=new mysqli("localhost","root","","project");
// Check connection
	if($con->connect_error){
		die("Connection failed: " . $con->connect_error);
	}
$W_ID = $_GET['id'];
$query = "delete from wish where W_ID = '$W_ID'";

$data = mysqli_query($con,$query);

if($data){
    echo "<script>alert ('Record deleted successfully!')</script>";
    header ("location:wishlist.php");
}
else{
    echo"<script>alert ('error')</script>";
}
mysqli_close($con);

?>    