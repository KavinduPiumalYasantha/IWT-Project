<!DOCTYPE html>
<html>
	<head>
		<style>
			table{
				border-collapse: collapse;
				width:100%;
				color: #004080;
				font-family: monospace;
				font-size: 20px;
				text-align:left;
			}

			th{
				background-color:#004080;
				color:#e6f2ff;
			}

			tr:nth-child(even){
				background-color:#e6f2ff;
			}
		</style>	
	</head>
<body>
<table>
	<tr>
		<th>ID</th>
		<th>Name</th>
		<th>Number</th>
		<th>Email</th>
		<th>Action</th>
    </tr>					
<?php
//Linking the configuration file

//The connection object
$con=new mysqli("localhost","root","","project");
// Check connection
	if($con->connect_error){
		die("Connection failed: " . $con->connect_error);
	}

$sql = "select S_ID,S_Name,S_Phone,S_Email from seller";
$result = $con->query($sql);



	if($result->num_rows > 0){
		//read data
		while($row = $result->fetch_assoc()){
		echo"
		<tr>
		    <td>".$row['S_ID']."</td>
			<td>".$row['S_Name']."</td>
			<td>".$row['S_Phone']."</td>
			<td>".$row['S_Email']."</td>
			<td><a href = 'sellerdelete.php?id=$row[S_ID]'>
			<input type='submit' value = 'Delete'></a></td>
		</tr>";	
		
		}
	}
	else
	{
		echo "no results";
	}
$con->close();
?>
</table>
</body>
</html>