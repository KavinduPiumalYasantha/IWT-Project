<!DOCTYPE html>
<html>
	<head>
		<style>
			table{
				border-collapse: collapse;
				width:100%;
				color: #004080;
				font-family: monospace;
				font-size: 20px;
				text-align:left;
			}

			th{
				background-color:#004080;
				color:#e6f2ff;
			}

			tr:nth-child(even){
				background-color:#e6f2ff;
			}
		</style>	
	</head>
<body>
<table>
	<tr>
		<th>ID</th>
		<th>Name</th>
		<th>Number</th>
		<th>Email</th>
		<th>Action</th>
    </tr>					
<?php
//Linking the configuration file

//The connection object
$con=new mysqli("localhost","root","","project");
// Check connection
	if($con->connect_error){
		die("Connection failed: " . $con->connect_error);
	}

$sql = "select C_ID,C_Name,C_Phone,C_Email from customer";
$result = $con->query($sql);



	if($result->num_rows > 0){
		//read data
		while($row = $result->fetch_assoc()){
		echo"
		<tr>
		    <td>".$row['C_ID']."</td>
			<td>".$row['C_Name']."</td>
			<td>".$row['C_Phone']."</td>
			<td>".$row['C_Email']."</td>
			<td><a href = 'customerdelete.php?id=$row[C_ID]'>
			<input type='submit' value = 'Delete'></a></td>
		</tr>";	
		
		}
	}
	else
	{
		echo "no results";
	}
$con->close();
?>
</table>
</body>
</html>