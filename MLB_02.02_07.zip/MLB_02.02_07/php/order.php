<!DOCTYPE html>
<html>
	<head>
		<style>
			table{
				border-collapse: collapse;
				width:100%;
				color: #004080;
				font-family: monospace;
				font-size: 20px;
				text-align:left;
			}

			th{
				background-color:#004080;
				color:#e6f2ff;
			}

			tr:nth-child(even){
				background-color:#e6f2ff;
			}
		</style>	
	</head>
<body>
<table>
	<tr>
		<th>Order ID</th>
		<th>Payment ID</th>
		<th>Action</th>
    </tr>					
<?php
//Linking the configuration file

//The connection object
$con=new mysqli("localhost","root","","project");
// Check connection
	if($con->connect_error){
		die("Connection failed: " . $con->connect_error);
	}

$sql = "select O_ID,P_ID from orders";
$result = $con->query($sql);



	if($result->num_rows > 0){
		//read data
		while($row = $result->fetch_assoc()){
		echo"
		<tr>
		    <td>".$row['O_ID']."</td>
			<td>".$row['P_ID']."</td>
			<td><a href = 'orderdelete.php?id=$row[O_ID]'>
			<input type='submit' value = 'Delete'></a></td>
		</tr>";	
		
		}
	}
	else
	{
		echo "no results";
	}
$con->close();
?>
</table>
</body>
</html>