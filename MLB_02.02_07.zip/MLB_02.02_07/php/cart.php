<!-- connecting to DB -->
<?php

include 'connection.php';


?>                              

<!DOCTYPE html> 



<html>
<title> Cart </title>
  <head>
  <!-- indlude style files and scrips --> 
        <link rel="stylesheet" href="../styles/profile.css" type="text/css"> 
        <link href="../styles/form.css" rel="stylesheet"> 
        <link href="../styles/cart.css" rel="stylesheet">
	    <script src="js/myscript.js"></script> 

  </head>
 <body>
     <table  class="headtable">
         <td><a href="IWT Project 2.HTML"><img src="../pic/logo.jpg" class="logo"></a></td>
         <td><form>
        
         </form></td>
         <td><button class="button">Add Book</button></td>
		 <td><button class="button">Order History</button></td>
        
         <td><img src="../pic/profile.jpg" class="profile">  </td>
      <!-- start navigation bar -->
	  </table>

          <div class="nav1">
              <a href="IWT Project 2.HTML"class = "home">Home</a>
              <a href="category.html "class = "category">Category</a>
              <a href="contact.html"class = "contact">Contact Us</a>
              <a href="about.html"class = "about">About Us</a>
          </div>
	  <!-- end navigation bar -->	  
		  
		  
		  <div class="warpper fl">
          <div class="main">
            
			
			
			
<div class="head">
	    <p>Payment Form</p>
</div>


  <!-- start payment form -->
<div class="form fm">
  <form method="POST">
                    

  
        <p class="name">Name On Card:</p>
          <p>
          <input type="text" name="un" placeholder="Name On Card" class="name-inp" required >
          </p>

        <p class="cn"> Card Number :</p>
          <p>
          <input type="number" name="cn"  placeholder="Card Number"  class="cn-inp" required>
          </p>

        <p class="cvv"> CVV :</p>
          <p>
          <input type="text" name="cvv" placeholder="cvv"  class="cvv-inp" pattern="[0-9]{3}">
	      </P>
    
	    <p class="date"> Expiary Date :</P>
          <p>
          <input type="date" name="date" class="date-inp"  required>
	      </p>

        <p>
          <input type="submit" name="sb" value="Pay" class="sub">
        </p>

  <!-- end payment form -->
  
  
</form>
?>
</div>
</div>
</div>
		  
		  
		 <!-- footer --> 
		  
	<footer>
  
        <table  class="footertable">
          <td><img src="../pic/Payment.jpg" class="paymentpic"></td>
          <td><h4 class="copytex"><b>Copyright @ 2021 by </b> ManThoughtsBookStore.com</h4></td>
          <td><a href="https://www.facebook.com/"><img src="../pic/fb.jpg" class="fbpic"></a></td>
          <td><a href="https://twitter.com/"><img src="../pic/twitter.jpg" class="fbpic"></a></td>
          <td><a href="https://www.instagram.com/"><img src="../pic/instagram.jpg" class="fbpic"></a></td>
          <td><a href="https://mail.google.com"><img src="../pic/gmail.jpg" class="fbpic"></a></td>
          <td><img src="../pic/app.jpg" class="apppic"></td>
        </table>
    </footer>
		
	    <!-- end footer --> 



</body>
</html>