<?php

$B_ID = $_POST['B_ID'];
$B_Name =  $_POST['B_Name'];
$B_Price =  $_POST['B_Price'];
$S_ID = $_POST['S_ID'];


$conn = new mysqli ('localhost', 'root','', 'project' ); // connect datbase


if($conn->connect_error) {

    die('Connection Failed : ' .$conn->connection_error); //dispaly error message

}else {

    $stmt = $conn->prepare("insert into book(B_ID, B_Name,B_Price, S_ID)values(?, ?, ?, ?)"); //sql query

    $stmt->bind_param("ssss", $B_ID, $B_Name, $B_Price, $S_ID);
    $stmt->execute();

    echo "<script>alert('Add Book Successfully...')</script>"; // dispaly successfully message
    $stmt->close();
    $conn->close();


}


?>