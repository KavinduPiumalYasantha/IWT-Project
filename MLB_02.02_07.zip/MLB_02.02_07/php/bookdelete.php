<?php
//Linking the configuration file

//The connection object
$con=new mysqli("localhost","root","","project");
// Check connection
	if($con->connect_error){
		die("Connection failed: " . $con->connect_error);
	}
$B_ID = $_GET['id'];
$query = "delete from book where B_ID = '$B_ID'";

$data = mysqli_query($con,$query);

if($data){
    echo "<script>alert ('Record deleted successfully!')</script>"; // dispaly successfully message
    header ("location:book.php");
}
else{
    echo"<script>alert ('erre')</script>"; //dispaly error message
}
mysqli_close($con);

?>    