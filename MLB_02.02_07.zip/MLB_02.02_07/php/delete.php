<?php
require 'dbconnection.php';

session_start();


if(isset($_POST['contactUs_btn']))
{
    global $conn;
    $name = $_POST ['name'];
    $email = $_POST['email'];
    $msg = $_POST['message'];


    $query = "INSERT INTO contactus(username,email,message)VALUES('$name','$email','$msg')";
    $query_run = mysqli_query($conn,$query);

    if($query_run)
    {
        $_SESSION['status'] = "Data inserted!";
        header("location: contactUS.php"); 
    }else{
        $_SESSION['status'] = "Data inserted failed!!";
        header("location: contactUS.php"); 
    }
}
?>