<!DOCTYPE html>
<html>
	<head>
		<style>
			table{
				border-collapse: collapse;
				width:100%;
				color: #004080;
				font-family: monospace;
				font-size: 20px;
				text-align:left;
			}

			th{
				background-color:#004080;
				color:#e6f2ff;
			}

			tr:nth-child(even){
				background-color:#e6f2ff;
			}
		</style>	
	</head>
<body>
<table>
	<tr>
		<th>Message ID</th>
		<th>Customer ID</th>
		<th>Message</th>
		<th>Action</th>
    </tr>					
<?php
//Linking the configuration file

//The connection object
$con=new mysqli("localhost","root","","project");
// Check connection
	if($con->connect_error){
		die("Connection failed: " . $con->connect_error);
	}

$sql = "select M_ID,C_ID,C_Message from chat";
$result = $con->query($sql);



	if($result->num_rows > 0){
		//read data
		while($row = $result->fetch_assoc()){
		echo"
		<tr>
		    <td>".$row['M_ID']."</td>
			<td>".$row['C_ID']."</td>
			<td>".$row['C_Message']."</td>
			<td><a href = 'chatdelete.php?id=$row[M_ID]'>
			<input type='submit' value = 'Delete'></a></td>
		</tr>";	
		
		}
	}
	else
	{
		echo "no results";
	}
$con->close();
?>
</table>
</body>
</html>