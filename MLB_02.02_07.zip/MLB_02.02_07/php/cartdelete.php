<?php
//Linking the configuration file

//The connection object
$con=new mysqli("localhost","root","","project");
// Check connection
	if($con->connect_error){
		die("Connection failed: " . $con->connect_error);
	}
$Cart_ID = $_GET['id'];
$query = "delete from cart where Cart_ID = '$Cart_ID'";

$data = mysqli_query($con,$query);

if($data){
    echo "<script>alert ('Record deleted successfully!')</script>"; // dispaly successfully message
    header ("location:cart.php");
}
else{
    echo"<script>alert ('error')</script>";  //dispaly error message
}
}
mysqli_close($con);

?>    