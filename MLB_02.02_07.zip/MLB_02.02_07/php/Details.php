<?php
    include once 'conection.php'
	
?>

<?php

      $name = $ POST["field1"];
	  $demail = $ POST["field2"]
	  $qty = $ POST["field3"]
	  
	  $sql = "insert into detailes(name, downloading email, quantity)values('name','demail','qty')";
	  
	  if(mysqli query($conn,$sql)) {
		  echo "<script>alert('Record insert Successfully!!!')</script>";         
          
		
      
      }else{
		  echo "<script>alert('Error in inserting records')</script>
                  header("Location: bookdownload.html");
	  }
	  
	  mysql close($conn);




?>