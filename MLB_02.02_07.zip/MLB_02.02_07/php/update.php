<?php session_start();?>
<!DOCTYPE html> 
<html>
    <title> Contact Us </title>
<head>
<link rel="stylesheet" href="css/test.css" type="text/css"> 
<link rel="stylesheet" href="css/contact_us.css"> 

<?php 
    $name = $_SESSION['name'];
    $email = $_SESSION['email'];
    $message = $_SESSION['message'];
?>
</head>
<body>
    <table  class="headtable">
        <td><a href="IWT Project 2.HTML"><img src="pic/logo.jpg" class="logo"></a></td>
        <td><form>
        <input type="sreach" name="Book" placeholder="Search Book" class="sreach" >
        </form></td>
        <td><button class="signin">Sign in</button></td>
        <td><button class="register">Register</button></td>
        <td><img src="pic/profile.jpg" class="profile">  </td>
     </table>

          <div class="nav1">
              <a href="IWT Project 2.HTML"class = "home">Home</a>
              <a href="category.html "class = "category">Category</a>
              <a href="contact.html"class = "contact">Contact Us</a>
              <a href="about.html"class = "about">About Us</a>
          </div>

          <div style="background-image: url(pic/bg8.jpg)">
            <section class="cntact">
                <!-- our details(address,mail,phone) show in here  -->
                <div class="cntainer">
                    <div class="contactInfo">
                        <div class="box">
                            <div class="icon"><img src="pic/address.png" width="50" height="50"></div>
                            <div class="text">
                                <h3>Address</h3>
                                <p>47,<br> Hyde Park Corner,<br>Colombo 02</p>
                            </div>
                        </div>
                        <div class="box">
                            <div class="icon"><img src="pic/call.png" width="50" height="50"></div>
                            <div class="text">
                                <h3>Phone</h3>
                                <p>Marketing&nbsp;&nbsp;&nbsp;&nbsp;: (011) 2335704<br>Admin&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: (011) 4xxxxxx<br></p>
                            </div>
                        </div>
                        <div class="box">
                            <div class="icon"><img src="pic/email.png" width="50" height="50"></div>
                            <div class="text">
                                <h3>Email</h3>
                                <p> Marketing&nbsp;&nbsp;&nbsp;&nbsp;: info@manthoughtbookstore.lk<br>Admin&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;: admin@manthoughtbookstore.lk<br></p>
                            </div>
                        </div>
                    </div>
                    <div class="contactForm">
                        <form action="contactvalidate.php" method="POST">
                            <h2>Contact Us</h2>
                        <!-- form with update and delete buttons -->
                            <?php
                            if(isset($_SESSION['status']))
                            {
                              echo "<h4>".$_SESSION['status']."</h4>";
                              unset($_SESSION['status']);
                            }
                            ?>
                            <div class="inputBox">
                                <label for ="name">Full Name :</label><br>
                                <input type="text" name="name" value="<?php echo $name; ?>" readonly>
                                
                            </div>
                            <div class="inputBox">
                                <label for ="email">Email :</label><br>
                                <input type="email" name="email" value="<?php echo $email; ?>" readonly>
                                
                            </div>
                            <div class="inputBox">
                            <label for ="message">Message :</label><br>
                                <input type = "text" name="message" value="<?php echo $message; ?>">
                                
                            </div>
                            <input type ="hidden" name = "mail" value ="<?php echo $email; ?>" >
                            <div class="inputBox">
                                <input type="submit" name="delete_btn" value="Delete">
                                <input type="submit" name="update_btn" value="Update">

                            </div>
                            </form>
                     </div>
                     </div>
                 </section>
             </div>   
             </div>
         </section>
     </div>
         
    <footer>
  
        <table  class="footertable">
          <td><img src="pic/Payment.jpg" class="paymentpic"></td>
          <td><h4 class="copytex"><b>Copyright @ 2021 by </b> ManThoughtsBookStore.com</h4></td>
          <td><a href="https://www.facebook.com/"><img src="pic/fb.jpg" class="fbpic"></a></td>
          <td><a href="https://twitter.com/"><img src="pic/twitter.jpg" class="fbpic"></a></td>
          <td><a href="https://www.instagram.com/"><img src="pic/instagram.jpg" class="fbpic"></a></td>
          <td><a href="https://mail.google.com"><img src="pic/gmail.jpg" class="fbpic"></a></td>
          <td><img src="pic/app.jpg" class="apppic"></td>
        </table>
    </footer>


</body>
</html>