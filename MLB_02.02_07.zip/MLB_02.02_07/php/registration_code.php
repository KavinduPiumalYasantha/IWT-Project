<!--
Here, we write code for registration.
-->
<?php
require_once('connection.php');
$fname = $lname = $phone= $email = $password = $pwd = '';

$fname = $_POST['firstname'];
$lname = $_POST['lastname'];
$phone = $_POST['phoneNo'];
$email = $_POST['email'];
$pwd = $_POST['password'];
$password = MD5($pwd);

$sql = "INSERT INTO tbluser (Firstname,Lastname,PhoneNo,Email,Password) VALUES ('$fname','$lname','$phone','$email','$password')";
$result = mysqli_query($conn, $sql);
if($result)
{
	header("Location: login.php");
}
else
{
	echo "Error :".$sql;
}
?>