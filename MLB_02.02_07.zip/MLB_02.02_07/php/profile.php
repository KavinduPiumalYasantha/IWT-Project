<!-- connecting to DB -->
<?php

include 'connection.php';


?>                              

<!DOCTYPE html> 
<html>
<title>Profile</title>

<!-- include style files and scrips -->

 <head>
    <link rel="stylesheet" href="../styles/Profile.css" type="text/css"> 
    <link href="../styles/form.css" rel="stylesheet" type="text/css"> 
	<script src="js/myscript.js"></script> 
 </head>
 
 <body>
    <table  class="headtable">
        <td><a href="IWT Project 2.HTML"><img src="../pic/logo.jpg" class="logo"></a></td>
        <td><form>
        </form></td>
        <td><button class="button">Add Book</a></button></td>
		<td><button class="button">Order History</a></button></td>
        <td><img src="../pic/profile.jpg" class="profile">  </td>
    </table>


<!-- start navigation bar -->
    <div class="nav1">
        <a href="IWT Project 2.HTML"class = "home">Home</a>
        <a href="category.html "class = "category">Category</a>
        <a href="contact.html"class = "contact">Contact Us</a>
        <a href="about.html"class = "about">About Us</a>
    </div>
<!-- end navigation bar -->		  
		  
		 
		 
<div class="warpper fl">
<div class="main">
    <div class="head">
     	<p>Personal Details</p>
    </div>


<!-- start profile form -->

<div class="form fm">
   
         
  <form method="POST">
                    
      <p class="name">Name:</p>
         <p>
            <input type="text" name="un" disabled id="name" value= "<?php echo $row["NAME"]?>" class="name-inp" required>
         </p>

      <p class="email"> E-mail :</p>
         <p>
            <input type="email" name="email" disabled id="email" value= "<?php echo $row["EMAIL"]?>" class="email-inp" pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$" required>
         </p>

      <p class="address"> Address :</p>
         <p>
            <input type="text" name="address" disabled id="address" value= "<?php echo $row["ADDRESS"]?>" class="address-inp">
	    </P>
    
	  <p class="phone"> Mobile Number :</P>
         <p>
            <input type="phone" name="phone" disabled id="phone" value= "<?php echo $row["MOBILE"]?>" class="phone-inp" pattern="[0-9]{10}" required>
	    </p>


      <p>
         <input type="button" name="edit" class="edit" id="edit" value="Edit" onClick=email.disabled=false;un.disabled=false;address.disabled=false;submit.disabled=false;phone.disabled=false;>
	  </p>

      <p>
          <input type="submit" name="sb" value="Save" class="save" onclick='mysaveFunction()'>
      </p>

      <p>
         <input type="submit" name="sb" value="Change password" class="sub">
      </p>


   </form>
?>
</div>
</div>
</div>

<!-- end profile form -->
		  
	
<!-- footer -->	
		  <footer>
  
        <table  class="footertable">
          <td><img src="../pic/Payment.jpg" class="paymentpic"></td>
          <td><h4 class="copytex"><b>Copyright @ 2021 by </b> ManThoughtsBookStore.com</h4></td>
          <td><a href="https://www.facebook.com/"><img src="../pic/fb.jpg" class="fbpic"></a></td>
          <td><a href="https://twitter.com/"><img src="../pic/twitter.jpg" class="fbpic"></a></td>
          <td><a href="https://www.instagram.com/"><img src="../pic/instagram.jpg" class="fbpic"></a></td>
          <td><a href="https://mail.google.com"><img src="../pic/gmail.jpg" class="fbpic"></a></td>
          <td><img src="../pic/app.jpg" class="apppic"></td>
        </table>
    </footer>
	
<!-- end footer -->		


</body>
</html>