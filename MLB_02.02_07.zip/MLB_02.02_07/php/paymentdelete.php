<?php
//Linking the configuration file

//The connection object
$con=new mysqli("localhost","root","","project");
// Check connection
	if($con->connect_error){
		die("Connection failed: " . $con->connect_error);
	}
$P_ID = $_GET['id'];
$query = "delete from payment where P_ID = '$P_ID'";

$data = mysqli_query($con,$query);

if($data){
    echo "<script>alert ('Record deleted successfully!')</script>";
    header ("location:payment.php");
}
else{
    echo"<script>alert ('erre')</script>";
}
mysqli_close($con);

?>    