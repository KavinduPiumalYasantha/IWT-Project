<?php
session_start();

$host="localhost"; 
$username="root";
$password="";
$db_name="bookstore";
$tbl_name="profile";

// Connect to server and select databse.
$con=mysqli_connect("$host", "$username", "$password")or die("cannot connect");
mysqli_select_db($con,"$db_name")or die("cannot select DB");

$sql="SELECT * FROM $tbl_name WHERE UID='1'";
$c_sql=mysqli_query($con,$sql);
$row=mysqli_fetch_array($c_sql,MYSQLI_ASSOC); 
